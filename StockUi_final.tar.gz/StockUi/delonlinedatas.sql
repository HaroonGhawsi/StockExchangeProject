delete stk_online_datas;
commit;
