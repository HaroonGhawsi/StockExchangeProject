#!/bin/bash
source ~/.bash_profile
node /home/oracle/WebstormProjects/StockUi/stock_snapshot.js

